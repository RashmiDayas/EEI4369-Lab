package com.s23010903.crafiqueapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class UserProfileActivity extends AppCompatActivity {

    TextView tvUserName;
    Button btnEditProfile, btnAddresses, btnOrderHistory, btnWishlist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        tvUserName = findViewById(R.id.tvUserName);
        btnEditProfile = findViewById(R.id.btnEditProfile);
        btnAddresses = findViewById(R.id.btnAddresses);
        btnOrderHistory = findViewById(R.id.btnOrderHistory);
        btnWishlist = findViewById(R.id.btnWishlist);

        // Optional: Set user's name dynamically
        tvUserName.setText("John Doe");

        btnEditProfile.setOnClickListener(v -> showToast("Edit Profile clicked"));
        btnAddresses.setOnClickListener(v -> showToast("Addresses clicked"));
        btnOrderHistory.setOnClickListener(v -> showToast("Order History clicked"));
        btnWishlist.setOnClickListener(v -> showToast("Wishlist clicked"));
    }

    private void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}

