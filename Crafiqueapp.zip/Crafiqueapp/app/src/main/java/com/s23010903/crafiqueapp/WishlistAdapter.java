package com.s23010903.crafiqueapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class WishlistAdapter extends BaseAdapter {

    Context context;
    String[] titles, prices;
    int[] images;
    LayoutInflater inflater;

    public WishlistAdapter(Context ctx, String[] titles, String[] prices, int[] images) {
        this.context = ctx;
        this.titles = titles;
        this.prices = prices;
        this.images = images;
        inflater = LayoutInflater.from(ctx);
    }

    @Override
    public int getCount() {
        return titles.length;
    }

    @Override
    public Object getItem(int i) {
        return titles[i];
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.wishlist_item, null);

        ImageView img = convertView.findViewById(R.id.imgItem);
        TextView title = convertView.findViewById(R.id.tvTitle);
        TextView price = convertView.findViewById(R.id.tvPrice);

        img.setImageResource(images[position]);
        title.setText(titles[position]);
        price.setText(prices[position]);

        return convertView;
    }
}