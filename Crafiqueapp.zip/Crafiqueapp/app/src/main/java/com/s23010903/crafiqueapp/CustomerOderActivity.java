package com.s23010903.crafiqueapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.*;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class CustomerOrderActivity extends AppCompatActivity {

    ImageView imgPreview;
    EditText etNote, etAlote;
    Button btnSubmit;
    Uri imageUri;

    static final int PICK_IMAGE_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_order);

        imgPreview = findViewById(R.id.imgPreview);
        etNote = findViewById(R.id.etNote);
        etAlote = findViewById(R.id.etAlote);
        btnSubmit = findViewById(R.id.btnSubmit);

        imgPreview.setOnClickListener(v -> openImagePicker());

        btnSubmit.setOnClickListener(v -> {
            String note = etNote.getText().toString();
            String alote = etAlote.getText().toString();

            if (note.isEmpty() || alote.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // TODO: Save to Firebase or local database
            Toast.makeText(this, "Request Submitted", Toast.LENGTH_SHORT).show();
        });
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
         startActivity(intent , PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            imageUri = data.getData();
            imgPreview.setImageURI(imageUri);
        }
    }
}
