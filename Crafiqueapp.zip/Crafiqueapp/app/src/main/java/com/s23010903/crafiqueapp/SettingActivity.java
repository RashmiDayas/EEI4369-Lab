package com.s23010903.crafiqueapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    Button btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        btnLogout = findViewById(R.id.btnLogout);

        btnLogout.setOnClickListener(v -> {
            Toast.makeText(SettingsActivity.this, "Logged out", Toast.LENGTH_SHORT).show();
            // Optionally navigate to login screen:
            // startActivity(new Intent(SettingsActivity.this, LoginActivity.class));
            // finish();
        });
    }
}

