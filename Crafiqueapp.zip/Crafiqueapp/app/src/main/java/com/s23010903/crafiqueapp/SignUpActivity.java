package com.s23010903.crafiqueapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignUpActivity {import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

    public class SignUpActivity extends AppCompatActivity {

        EditText etEmail, etPassword, etConfirmPassword, etPhone;
        Button btnSignUp;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_sign_up);

            etEmail = findViewById(R.id.etEmail);
            etPassword = findViewById(R.id.etPassword);
            etConfirmPassword = findViewById(R.id.etConfirmPassword);
            etPhone = findViewById(R.id.etPhone);
            btnSignUp = findViewById(R.id.btnSignUp);

            btnSignUp.setOnClickListener(v -> {
                String email = etEmail.getText().toString();
                String password = etPassword.getText().toString();
                String confirmPassword = etConfirmPassword.getText().toString();
                String phone = etPhone.getText().toString();

                if (!password.equals(confirmPassword)) {
                    Toast.makeText(com.s23010903.Ceafiqueapp.SignUpActivity.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(com.s23010903.Crafiqueapp.SignUpActivity.this, "Sign Up Successful!", Toast.LENGTH_SHORT).show();
                    // You can add intent to move to login or main page
                }
            });
        }
    }

}
