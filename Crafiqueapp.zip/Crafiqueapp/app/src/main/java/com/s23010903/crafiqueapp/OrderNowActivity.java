package com.s23010903.crafiqueapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class OrderNowActivity extends AppCompatActivity {

    EditText etItem, etSize, etArea;
    Button btnAddOrder, btnComplete;
    TextView tvOrderDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_now);

        etItem = findViewById(R.id.etItem);
        etSize = findViewById(R.id.etSize);
        etArea = findViewById(R.id.etArea);
        btnAddOrder = findViewById(R.id.btnAddOrder);
        btnComplete = findViewById(R.id.btnComplete);
        tvOrderDetails = findViewById(R.id.tvOrderDetails);

        btnAddOrder.setOnClickListener(v -> {
            String item = etItem.getText().toString();
            String size = etSize.getText().toString();
            String area = etArea.getText().toString();

            if (item.isEmpty() || size.isEmpty() || area.isEmpty()) {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show();
            } else {
                String orderDetails = "Item: " + item + "\nSize: " + size + "\nArea: " + area;
                tvOrderDetails.setText(orderDetails);
            }
        });

        btnComplete.setOnClickListener(v -> {
            Toast.makeText(this, "Order completed!", Toast.LENGTH_SHORT).show();
            // Optionally clear fields or send order to Firebase here
        });
    }
}

