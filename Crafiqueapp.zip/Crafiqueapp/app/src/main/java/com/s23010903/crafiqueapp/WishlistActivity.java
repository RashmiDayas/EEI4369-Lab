package com.s23010903.crafiqueapp;

import android.os.Bundle;
import android.widget.GridView;
import androidx.appcompat.app.AppCompatActivity;

public class WishlistActivity extends AppCompatActivity {

    GridView gridWishlist;

    int[] images = {
            R.drawable.sample1, R.drawable.sample2,
            R.drawable.sample3, R.drawable.sample4
    };

    String[] titles = {
            "Flower Baquate", "Handmade Candle", "One Flower", "One Flower"
    };

    String[] prices = {
            "Rs.2500/=", "Rs.800/=", "Rs.250/=", "Rs.250/="
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wishlist);

        gridWishlist = findViewById(R.id.gridWishlist);
        WishlistAdapter adapter = new WishlistAdapter(this, titles, prices, images);
        gridWishlist.setAdapter(adapter);
    }
}
